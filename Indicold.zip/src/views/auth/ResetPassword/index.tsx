import ResetPassword from './ResetPassword'

export default ResetPassword
