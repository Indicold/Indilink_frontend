import BasicInformation from './BasicInformation'

export default BasicInformation;