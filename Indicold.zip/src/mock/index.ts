export { mockServer as default } from './mock'
