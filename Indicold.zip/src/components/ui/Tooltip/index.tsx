import Tooltip from './Tooltip'

export type { TooltipProps } from './Tooltip'
export { Tooltip }

export default Tooltip
