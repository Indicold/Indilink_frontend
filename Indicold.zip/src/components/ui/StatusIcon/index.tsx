import StatusIcon from './StatusIcon'

export type { StatusIconProps } from './StatusIcon'
export default StatusIcon
