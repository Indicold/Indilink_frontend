import Layouts from './Layouts'

export default Layouts
