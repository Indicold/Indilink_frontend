import Input from './Input'

export type { InputProps } from './Input'
export { Input }

export default Input
