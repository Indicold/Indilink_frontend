import { createMemoryHistory } from 'history'

const history = createMemoryHistory()

export default history
