import VerfyOtpForm from "./VerifyOtpForm"
const VerfyOtp = () => {
    return <VerfyOtpForm disableSubmit={false} />
}

export default VerfyOtp
