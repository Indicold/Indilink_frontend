/* The code is importing the `VerfyOtp` component from the file `VerifyOtp.js` (or `VerifyOtp.tsx` if
using TypeScript) and then exporting it as the default export. This allows other files to import and
use the `VerfyOtp` component. */
import VerfyOtp from './VerifyOtp'

export default VerfyOtp
