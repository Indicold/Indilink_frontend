import VerfyOtp from './VerifyOtp'

export default VerfyOtp
